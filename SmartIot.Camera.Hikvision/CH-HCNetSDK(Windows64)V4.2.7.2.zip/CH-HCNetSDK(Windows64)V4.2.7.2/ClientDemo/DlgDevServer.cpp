// DlgDevServer.cpp : implementation file
//

#include "stdafx.h"
#include "clientdemo.h"
#include "DlgDevServer.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgDevServer dialog


CDlgDevServer::CDlgDevServer(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgDevServer::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgDevServer)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	memset(&m_struDevServerCfg, 0, sizeof(m_struDevServerCfg));
}


void CDlgDevServer::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgDevServer)
	DDX_Control(pDX, IDC_COMBO_TELNET_SERVER, m_comboTelnetServer);
	DDX_Control(pDX, IDC_COMBO_IRLAMP_SERVER, m_comboIRLampServer);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgDevServer, CDialog)
	//{{AFX_MSG_MAP(CDlgDevServer)
	ON_BN_CLICKED(IDC_BTN_SET, OnBtnSet)
	ON_BN_CLICKED(IDC_BTN_GET, OnBtnGet)
	ON_WM_CANCELMODE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgDevServer message handlers

void CDlgDevServer::OnBtnSet() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	char szLan[128] = {0};
	m_struDevServerCfg.byIrLampServer = m_comboIRLampServer.GetCurSel();
	m_struDevServerCfg.bytelnetServer = m_comboTelnetServer.GetCurSel();
	m_struDevServerCfg.dwSize = sizeof(m_struDevServerCfg);
	if (!NET_DVR_SetDVRConfig(m_lServerID,NET_DVR_SET_DEVSERVER_CFG, m_nChannel,&m_struDevServerCfg, sizeof(m_struDevServerCfg)))	
	{
		g_pMainDlg->AddLog(m_dwDevIndex, OPERATION_FAIL_T, "NET_DVR_SET_DEVSERVER_CFG %d",NET_DVR_GetLastError());
		g_StringLanType(szLan, "��������ʧ��", "Save failed");
		AfxMessageBox(szLan);
	}
	else
	{
		g_pMainDlg->AddLog(m_dwDevIndex, OPERATION_SUCC_T, "NET_DVR_SET_DEVSERVER_CFG %d",NET_DVR_GetLastError());
	}
}

void CDlgDevServer::OnBtnGet() 
{
	// TODO: Add your control notification handler code here
	DWORD dwReturn = 0;
	char szLan[128] = {0};
	
    if (!NET_DVR_GetDVRConfig(m_lServerID, NET_DVR_GET_DEVSERVER_CFG, m_nChannel, &m_struDevServerCfg,sizeof(m_struDevServerCfg), &dwReturn))
    {
        g_pMainDlg->AddLog(m_dwDevIndex, OPERATION_FAIL_T, "NET_DVR_GET_DEVSERVER_CFG %d",NET_DVR_GetLastError());
		g_StringLanType(szLan, "������ȡʧ��", "Get failed");
		AfxMessageBox(szLan);
    }
	else
	{
		g_pMainDlg->AddLog(m_dwDevIndex, OPERATION_SUCC_T, "NET_DVR_GET_DEVSERVER_CFG %d",NET_DVR_GetLastError());
	}
	m_comboIRLampServer.SetCurSel(m_struDevServerCfg.byIrLampServer);
	m_comboTelnetServer.SetCurSel(m_struDevServerCfg.bytelnetServer);
	UpdateData(FALSE);
}

BOOL CDlgDevServer::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	OnBtnGet();
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgDevServer::OnCancelMode() 
{
	CDialog::OnCancelMode();
	
	// TODO: Add your message handler code here
	
}
