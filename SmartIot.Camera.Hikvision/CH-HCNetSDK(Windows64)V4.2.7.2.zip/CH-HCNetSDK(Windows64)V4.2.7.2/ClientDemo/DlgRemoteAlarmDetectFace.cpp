// DlgRemoteAlarmDetectFace.cpp : implementation file
//

#include "stdafx.h"
#include "clientdemo.h"
#include "DlgRemoteAlarmDetectFace.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgRemoteAlarmDetectFace dialog


CDlgRemoteAlarmDetectFace::CDlgRemoteAlarmDetectFace(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgRemoteAlarmDetectFace::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgRemoteAlarmDetectFace)
	m_bChkEmapAlarmOut = FALSE;
	m_bChkInvokeAlarmOut = FALSE;
	m_bChkMonitorAlarm = FALSE;
	m_bChkUploadCenter = FALSE;
	m_bChkVoiceAlarm = FALSE;
	m_bChkInvokeJpegCapture = FALSE;
	m_bChkPicToFtp = FALSE;
	m_bChkFaceDetect = FALSE;
	m_bChkEnableDisPlay = FALSE;
	//}}AFX_DATA_INIT

	memset(&m_struDetectFaceCfg, 0, sizeof(m_struDetectFaceCfg));
	//memset(&m_struChannelGroup, 0, sizeof(m_struChannelGroup));

	memset(&m_dwAlarmOut, 0, sizeof(m_dwAlarmOut));
	memset(&m_dwRecordChan, 0, sizeof(m_dwRecordChan));

	for (int i = 0; i < MAX_CHANNUM_V30; i++)
	{
		m_struDetectFaceCfg.struAlarmHandleType.dwRelAlarmOut[i] = 0xffffffff;
		m_struDetectFaceCfg.dwRelRecordChan[i] = 0xffffffff;
	}
	
	m_dwMaxRelAlarmOutNum = 0;
	m_dwMaxRelRecordChanNum = 0;
}


void CDlgRemoteAlarmDetectFace::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgRemoteAlarmDetectFace)
	DDX_Control(pDX, IDC_COM_DETECT_SENSITIVE, m_comDetectSensitive);
	DDX_Control(pDX, IDC_TREE_ALARM_OUT, m_treeAlarmOut);
	DDX_Control(pDX, IDC_TREE_CHAN, m_treeChan);
	DDX_Check(pDX, IDC_CHK_ALARM_EMAP, m_bChkEmapAlarmOut);
	DDX_Check(pDX, IDC_CHK_ALARMIN_INVOKE_ALARMOUT, m_bChkInvokeAlarmOut);
	DDX_Check(pDX, IDC_CHK_ALARMIN_MONITOR, m_bChkMonitorAlarm);
	DDX_Check(pDX, IDC_CHK_ALARMIN_UPLOAD_CENTER, m_bChkUploadCenter);
	DDX_Check(pDX, IDC_CHK_ALARMIN_VOICE, m_bChkVoiceAlarm);
	DDX_Check(pDX, IDC_CHK_INVOKE_JPEG_CAPTURE, m_bChkInvokeJpegCapture);
	DDX_Check(pDX, IDC_CHK_PIC_FTP, m_bChkPicToFtp);
	DDX_Check(pDX, IDC_CHK_ENABLE_FACE_DETECT, m_bChkFaceDetect);
	DDX_Check(pDX, IDC_CHK_ENABLE_DISPLAY, m_bChkEnableDisPlay);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgRemoteAlarmDetectFace, CDialog)
	//{{AFX_MSG_MAP(CDlgRemoteAlarmDetectFace)
	ON_BN_CLICKED(IDC_BTN_ALARM_IN_TIME_OK, OnBtnAlarmInTimeOk)
	ON_NOTIFY(NM_CLICK, IDC_TREE_ALARM_OUT, OnClickTreeAlarmOut)
	ON_BN_CLICKED(IDC_BTN_ALARMIN_OK, OnBtnAlarminOk)
	ON_WM_CANCELMODE()
	ON_NOTIFY(NM_CLICK, IDC_TREE_CHAN, OnClickTreeChan)
	ON_BN_CLICKED(IDC_BTN_ALARMIN_UPLOAD, OnBtnAlarminUpload)
	ON_BN_CLICKED(IDC_BTN_ALARMIN_EXIT, OnBtnAlarminExit)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgRemoteAlarmDetectFace message handlers

void CDlgRemoteAlarmDetectFace::OnBtnAlarmInTimeOk() 
{
	// TODO: Add your control notification handler code here
	
}

/*********************************************************
  Function:	CreateTree
  Desc:		establish alarm out - video connection
  Input:	
  Output:	
  Return:	
**********************************************************/
void CDlgRemoteAlarmDetectFace::CreateTree(void)
{
	m_treeChan.DeleteAllItems();
	CString strTemp =_T("");
	CString strChanTmp = _T("");
	int i = 0;
	HTREEITEM hChanItem = NULL;
	if (m_iChanCount <= 0)
	{
		m_treeAlarmOut.EnableWindow(FALSE);
		m_treeChan.EnableWindow(FALSE);
	}

	int iChanShow = 0;

	for (i = 0; i < MAX_CHANNUM_V30; i++)
	{
		iChanShow = g_struDeviceInfo[m_dwDevIndex].struChanInfo[i].iChannelNO;

		if ((i < m_iAnaChanCount) && g_struDeviceInfo[m_dwDevIndex].struChanInfo[i].bEnable)
		{
			strTemp.Format(ANALOG_C_FORMAT, iChanShow);
			hChanItem =  m_treeChan.InsertItem(strTemp, 0, 0, TVI_ROOT);
			m_treeChan.SetItemData(hChanItem, iChanShow/*0*1000 + i*/);	
			if (0xffffffff != m_struDetectFaceCfg.dwRelRecordChan[i])
			{
				m_treeChan.SetCheck(hChanItem, TRUE);
			}
		}
		else if (i >= m_iAnaChanCount && g_struDeviceInfo[m_dwDevIndex].struChanInfo[i].bEnable)
		{
			strTemp.Format(DIGITAL_C_FORMAT, iChanShow - m_iDStartChannel + 1);
			hChanItem =  m_treeChan.InsertItem(strTemp, 0, 0, TVI_ROOT);
			m_treeChan.SetItemData(hChanItem, iChanShow/*0*1000 + i*/);	
			if (0xffffffff != m_struDetectFaceCfg.dwRelRecordChan[i])
			{
				m_treeChan.SetCheck(hChanItem, TRUE);
			}
		}
	}
	m_treeChan.SelectItem(hChanItem);
	m_treeChan.Expand(m_treeChan.GetRootItem(),TVE_EXPAND);	

	m_treeAlarmOut.DeleteAllItems();
	CString strTempAlarmOut =_T("");
	CString strChanTmpAlarmOut = _T("");
	for (i = 0; i < MAX_CHANNUM_V30; i++)
	{
		iChanShow = g_struDeviceInfo[m_dwDevIndex].struChanInfo[i].iChannelNO;
		
		if ((i < m_iAnaChanCount) && g_struDeviceInfo[m_dwDevIndex].struChanInfo[i].bEnable)
		{
			strTempAlarmOut.Format(ANALOG_C_FORMAT, iChanShow);
			hChanItem =  m_treeAlarmOut.InsertItem(strTempAlarmOut, 0, 0, TVI_ROOT);
			m_treeAlarmOut.SetItemData(hChanItem, iChanShow/*0*1000 + i*/);	
			if (0xffffffff != m_struDetectFaceCfg.struAlarmHandleType.dwRelAlarmOut[i])
			{
				m_treeAlarmOut.SetCheck(hChanItem, TRUE);
			}
		}
		else if (i >= m_iAnaChanCount && g_struDeviceInfo[m_dwDevIndex].struChanInfo[i].bEnable)
		{
			strTempAlarmOut.Format(DIGITAL_C_FORMAT, iChanShow);
			hChanItem =  m_treeAlarmOut.InsertItem(strTempAlarmOut, 0, 0, TVI_ROOT);
			m_treeAlarmOut.SetItemData(hChanItem, iChanShow/*0*1000 + i*/);	
			if (0xffffffff != m_struDetectFaceCfg.struAlarmHandleType.dwRelAlarmOut[i])
			{
				m_treeAlarmOut.SetCheck(hChanItem, TRUE);
			}
		}
	}
	m_treeAlarmOut.SelectItem(hChanItem);
	m_treeAlarmOut.Expand(m_treeAlarmOut.GetRootItem(),TVE_EXPAND);	
}


void CDlgRemoteAlarmDetectFace::OnClickTreeChan(NMHDR* pNMHDR, LRESULT* pResult) 
{
	UpdateData(TRUE);
	CPoint pt(0,0);
	CRect rc(0,0,0,0);
	GetCursorPos(&pt);
	GetDlgItem(IDC_TREE_CHAN)->GetWindowRect(&rc);
	ScreenToClient(&rc);
	ScreenToClient(&pt);
	pt.x = pt.x - rc.left;
	pt.y = pt.y - rc.top;

	UINT uFlag = 0;
	HTREEITEM hSelect = m_treeChan.HitTest(pt, &uFlag);

	if (NULL == hSelect) 
	{
		return;
	}
	m_treeChan.SelectItem(hSelect);
	DWORD dwIndex = m_treeChan.GetItemData(hSelect)%1000;
	BOOL bCheck = m_treeChan.GetCheck(hSelect);
	if (bCheck)
	{
		m_dwRecordChan[dwIndex] = dwIndex + 1;
	}
	else
	{
		m_dwRecordChan[dwIndex] = 0xffffffff;
	}

	//switch checkbox status on click
	if (uFlag != LVHT_TOLEFT)
	{
		m_treeChan.SetCheck(hSelect, !bCheck);
	}
	else
	{
		m_treeChan.SetCheck(hSelect, bCheck);
	}

	*pResult = 0;
}

void CDlgRemoteAlarmDetectFace::OnClickTreeAlarmOut(NMHDR* pNMHDR, LRESULT* pResult) 
{
	UpdateData(TRUE);
	CPoint pt(0,0);
	CRect rc(0,0,0,0);
	GetCursorPos(&pt);
	GetDlgItem(IDC_TREE_ALARM_OUT)->GetWindowRect(&rc);
	ScreenToClient(&rc);
	ScreenToClient(&pt);
	pt.x = pt.x - rc.left;
	pt.y = pt.y - rc.top;

	UINT uFlag = 0;
	HTREEITEM hSelect = m_treeAlarmOut.HitTest(pt, &uFlag);

	if (NULL == hSelect) 
	{
		return;
	}
	m_treeAlarmOut.SelectItem(hSelect);
	DWORD dwIndex = m_treeAlarmOut.GetItemData(hSelect)%1000;
	BOOL bCheck = m_treeAlarmOut.GetCheck(hSelect);
	if (bCheck)
	{
		m_dwAlarmOut[dwIndex] = dwIndex + 1;
	}
	else
	{
		m_dwAlarmOut[dwIndex] = 0xffffffff;
	}
	
	//switch checkbox status on click
	if (uFlag != LVHT_TOLEFT)
	{
		m_treeAlarmOut.SetCheck(hSelect, !bCheck);
	}
	else
	{
		m_treeAlarmOut.SetCheck(hSelect, bCheck);
	}

	*pResult = 0;
}

void CDlgRemoteAlarmDetectFace::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	CreateTree();
	// Do not call CDialog::OnPaint() for painting messages
}


void CDlgRemoteAlarmDetectFace::OnBtnAlarminOk() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	int i = 0;
	m_struDetectFaceCfg.dwSize = sizeof(m_struDetectFaceCfg);
	for (i = 0; i < MAX_CHANNUM_V30; i++)
	{
		if (m_dwRecordChan[i] != 0xffffffff)
		{
			m_struDetectFaceCfg.dwRelRecordChan[i] = (DWORD)m_dwRecordChan[i];
		}
	}

	for (i=0; i < MAX_CHANNUM_V30; i++)
	{
		if (m_dwAlarmOut[i] != 0xffffffff)
		{
			m_struDetectFaceCfg.struAlarmHandleType.dwRelAlarmOut[i] = (DWORD)m_dwAlarmOut[i];
		}	
	}
	
	m_struDetectFaceCfg.struAlarmHandleType.dwHandleType = 0;
	m_struDetectFaceCfg.struAlarmHandleType.dwHandleType |= (m_bChkMonitorAlarm << 0);
	m_struDetectFaceCfg.struAlarmHandleType.dwHandleType |= (m_bChkVoiceAlarm << 1);
	m_struDetectFaceCfg.struAlarmHandleType.dwHandleType |= (m_bChkUploadCenter << 2);
	m_struDetectFaceCfg.struAlarmHandleType.dwHandleType |= (m_bChkInvokeAlarmOut << 3);
	m_struDetectFaceCfg.struAlarmHandleType.dwHandleType |= (m_bChkInvokeJpegCapture << 4);
	m_struDetectFaceCfg.struAlarmHandleType.dwHandleType |= (m_bChkEmapAlarmOut<<6);
	m_struDetectFaceCfg.struAlarmHandleType.dwHandleType |= (m_bChkPicToFtp << 9);	
	
	m_struDetectFaceCfg.byEnableDetectFace = m_bChkFaceDetect;
	m_struDetectFaceCfg.byEnableDisplay = m_bChkEnableDisPlay;
	m_struDetectFaceCfg.byDetectSensitive = m_comDetectSensitive.GetCurSel() + 1;

	m_struChannelGroup.dwSize = sizeof(m_struChannelGroup);
	m_struChannelGroup.dwGroup = 0;
	m_struChannelGroup.dwChannel = 1;

	int iItemCount = 1;
	DWORD *pStatus = new DWORD[iItemCount];
	memset(pStatus, 0, sizeof(DWORD)*iItemCount);

	if (!NET_DVR_SetDeviceConfig(m_lServerID,NET_DVR_SET_FACE_DETECT, iItemCount,&m_struChannelGroup, sizeof(m_struChannelGroup), pStatus, \
		&m_struDetectFaceCfg, sizeof(m_struDetectFaceCfg)))
	{
		g_pMainDlg->AddLog(m_lServerID, OPERATION_FAIL_T, "NET_DVR_SET_FACE_DETECT");
        return;
	}
	else
	{
		g_pMainDlg->AddLog(m_lServerID, OPERATION_SUCC_T, "NET_DVR_SET_FACE_DETECT");
	}
}

BOOL CDlgRemoteAlarmDetectFace::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	//CreateTree();
	OnBtnAlarminUpload();
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgRemoteAlarmDetectFace::OnCancelMode() 
{
	CDialog::OnCancelMode();
	
	// TODO: Add your message handler code here
	
}

void CDlgRemoteAlarmDetectFace::OnBtnAlarminUpload() 
{
	// TODO: Add your control notification handler code here
	//memset(&m_struChannelGroup, 0, sizeof(m_struChannelGroup));
	m_struChannelGroup.dwSize = sizeof(m_struChannelGroup);
	m_struChannelGroup.dwGroup = 0;
	m_struChannelGroup.dwChannel = 1;
    int i = 0;
	int iItemCount = 1;
	char szLan[128] = {0};

	DWORD *pStatus = new DWORD[iItemCount];
	memset(pStatus, 0, sizeof(DWORD)*iItemCount);
 
// 	NET_DVR_DETECT_FACE  struDetectFaceCfg[2];
// 	NET_DVR_CHANNEL_GROUP struChannelGroup[2];
// 
// 	memset(&struDetectFaceCfg, 0 ,sizeof(struDetectFaceCfg));
// 	memset(&struChannelGroup, 0, sizeof(struChannelGroup));
// 
// 	for (i = 0; i < 2; i++)
// 	{
// 		struChannelGroup[i].dwSize = sizeof(NET_DVR_CHANNEL_GROUP);
// 		struChannelGroup[i].dwGroup = i;
// 		struChannelGroup[i].dwChannel = i + 1;
// 	}
// 
// 	if (NET_DVR_GetDeviceConfig(m_lServerID, NET_DVR_GET_FACE_DETECT, iItemCount, &struChannelGroup, \
// 		iItemCount*sizeof(NET_DVR_CHANNEL_GROUP), pStatus, &struDetectFaceCfg, iItemCount*sizeof(NET_DVR_DETECT_FACE)))
// 	{
// 		g_pMainDlg->AddLog(m_lServerID, OPERATION_SUCC_T, "NET_DVR_GET_FACE_DETECT");
// 	}
// 	else
// 	{
// 		g_pMainDlg->AddLog(m_lServerID, OPERATION_FAIL_T, "NET_DVR_GET_FACE_DETECT");
// 		return;
// 	}
// 
// 	for (i=0; i<iItemCount; i++)
// 	{
// 		if (*pStatus != 0)
// 		{
// 			sprintf(szLan,"����״̬����ֵ:%d",*pStatus);
// 			AfxMessageBox(szLan);
// 		}
// 		sprintf(szLan,"��ȷ״̬����ֵ:%d",*pStatus);
// 		AfxMessageBox(szLan);
// 		pStatus++;
// 	}

	if (NET_DVR_GetDeviceConfig(m_lServerID, NET_DVR_GET_FACE_DETECT, iItemCount, &m_struChannelGroup, \
		iItemCount*sizeof(m_struChannelGroup), pStatus, &m_struDetectFaceCfg, iItemCount*sizeof(m_struDetectFaceCfg)))
	{
		g_pMainDlg->AddLog(m_lServerID, OPERATION_SUCC_T, "NET_DVR_GET_FACE_DETECT");
	}
	else
	{
		g_pMainDlg->AddLog(m_lServerID, OPERATION_FAIL_T, "NET_DVR_GET_FACE_DETECT");
		return;
	}

	for (i=0; i<iItemCount; i++)
	{
		if (*pStatus != 0)
		{
			sprintf(szLan,"����״̬����ֵ:%d",*pStatus);
			AfxMessageBox(szLan);
		}
		sprintf(szLan,"��ȷ״̬����ֵ:%d",*pStatus);
		AfxMessageBox(szLan);
		pStatus++;
	}

	m_bChkMonitorAlarm = m_struDetectFaceCfg.struAlarmHandleType.dwHandleType &0x01;
	m_bChkVoiceAlarm = (m_struDetectFaceCfg.struAlarmHandleType.dwHandleType>>1)&0x01;
	m_bChkUploadCenter = (m_struDetectFaceCfg.struAlarmHandleType.dwHandleType>>2)&0x01;
	m_bChkInvokeAlarmOut = (m_struDetectFaceCfg.struAlarmHandleType.dwHandleType>>3)&0x01;
	m_bChkInvokeJpegCapture = (m_struDetectFaceCfg.struAlarmHandleType.dwHandleType>>4)&0x01;
	m_bChkEmapAlarmOut = (m_struDetectFaceCfg.struAlarmHandleType.dwHandleType>>6)&0x01;
	m_bChkPicToFtp = (m_struDetectFaceCfg.struAlarmHandleType.dwHandleType>>9)&0x01;

	for (i=0;i<MAX_CHANNUM_V30;i++)
	{
		m_dwAlarmOut[i] = m_struDetectFaceCfg.struAlarmHandleType.dwRelAlarmOut[i];
	}
	for (i=0; i< MAX_CHANNUM_V30; i++)
	{
		m_dwRecordChan[i] = m_struDetectFaceCfg.dwRelRecordChan[i];
	}

	m_bChkFaceDetect = m_struDetectFaceCfg.byEnableDetectFace;
	m_bChkEnableDisPlay = m_struDetectFaceCfg.byEnableDisplay;
	m_comDetectSensitive.SetCurSel(m_struDetectFaceCfg.byDetectSensitive - 1);

	m_dwMaxRelAlarmOutNum = m_struDetectFaceCfg.struAlarmHandleType.dwMaxRelAlarmOutChanNum;
	m_dwMaxRelRecordChanNum = m_struDetectFaceCfg.dwMaxRelRecordChanNum;

	CreateTree();
	UpdateData(FALSE);
}

void CDlgRemoteAlarmDetectFace::OnBtnAlarminExit() 
{
	// TODO: Add your control notification handler code here
	CDialog::OnCancel();
}
