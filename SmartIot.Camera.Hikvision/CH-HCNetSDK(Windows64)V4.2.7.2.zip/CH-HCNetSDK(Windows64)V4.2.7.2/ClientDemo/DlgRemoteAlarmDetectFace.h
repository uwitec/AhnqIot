#if !defined(AFX_DLGREMOTEALARMDETECTFACE_H__16F05015_6B54_4BB6_9D91_88B8B4A8200C__INCLUDED_)
#define AFX_DLGREMOTEALARMDETECTFACE_H__16F05015_6B54_4BB6_9D91_88B8B4A8200C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgRemoteAlarmDetectFace.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgRemoteAlarmDetectFace dialog

class CDlgRemoteAlarmDetectFace : public CDialog
{
// Construction
public:
	CDlgRemoteAlarmDetectFace(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgRemoteAlarmDetectFace)
	enum { IDD = IDD_DLG_REMOTE_ALARM_DETECT_FACE };
	CComboBox	m_comDetectSensitive;
	CTreeCtrl	m_treeAlarmOut;
	CTreeCtrl	m_treeChan;
	BOOL	m_bChkEmapAlarmOut;
	BOOL	m_bChkInvokeAlarmOut;
	BOOL	m_bChkMonitorAlarm;
	BOOL	m_bChkUploadCenter;
	BOOL	m_bChkVoiceAlarm;
	BOOL	m_bChkInvokeJpegCapture;
	BOOL	m_bChkPicToFtp;
	BOOL	m_bChkFaceDetect;
	BOOL	m_bChkEnableDisPlay;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgRemoteAlarmDetectFace)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgRemoteAlarmDetectFace)
	afx_msg void OnBtnAlarmInTimeOk();
	afx_msg void OnClickTreeAlarmOut(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnBtnAlarminOk();
	virtual BOOL OnInitDialog();
	afx_msg void OnCancelMode();
	afx_msg void OnClickTreeChan(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnPaint();
	afx_msg void OnBtnAlarminUpload();
	afx_msg void OnBtnAlarminExit();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	int		m_iChanCount;
	int		m_iAnaChanCount;
	int     m_iDStartChannel;
	LONG	m_lStartChannel;
	int     m_iCopyTime;
	DWORD   m_dwAlarmInNum;
	DWORD   m_dwAlarmOutNum;
	BOOL TimeTest();
	void CreateTree();
	DWORD   m_dwAlarmOut[MAX_CHANNUM_V30];
	DWORD   m_dwRecordChan[MAX_CHANNUM_V30];
	DWORD   m_dwDevIndex;
    LONG    m_lServerID;
    LONG    m_lAlarmInIndex; 

	NET_DVR_DETECT_FACE  m_struDetectFaceCfg;
	NET_DVR_CHANNEL_GROUP m_struChannelGroup;

	DWORD m_dwMaxRelAlarmOutNum;
	DWORD m_dwMaxRelRecordChanNum;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGREMOTEALARMDETECTFACE_H__16F05015_6B54_4BB6_9D91_88B8B4A8200C__INCLUDED_)
